Hello,
This is a readme file
The contents of the file are as follows
1. Fun stuff
2. Awesome facts
3. Sound arguments
Thanks for reading!